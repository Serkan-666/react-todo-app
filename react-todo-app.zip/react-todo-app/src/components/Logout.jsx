
export default function Logout() {
  localStorage.clear()
  return null
}
